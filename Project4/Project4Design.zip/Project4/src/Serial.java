
/**
 * Parent class for Joruanls and Conference papers
 * @author John Frashier
 *
 */

public class Serial {

}
