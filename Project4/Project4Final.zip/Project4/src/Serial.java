
/**
 * Parent class for Joruanls and Conference papers
 *
 */

public class Serial {
	//subclass me
}
