public class Driver {
	
	public static void main (String[] args) {
		
	}

	/**
	 * Retrieves user input for file location & search term
	 * 
	 * @return user input
	 */
	public String getInput() {
		
		return "Driver.getInput() is not implemented";
	}
}
