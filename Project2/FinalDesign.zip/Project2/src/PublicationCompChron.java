import java.util.Comparator;


public class PublicationCompChron implements Comparator<Publication> {

	@Override
	public int compare(Publication o1, Publication o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
