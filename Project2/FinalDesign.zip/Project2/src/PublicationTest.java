import static org.junit.Assert.*;

import org.junit.Test;


public class PublicationTest {

	@Test
	public void testPublicationNoLink() {
		fail("Not yet implemented");
	}

	@Test
	public void testPublicationWithLink() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsNumeric() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAuthors() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddAuthor() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveAuthor() {
		fail("Not yet implemented");
	}

}
