import java.io.Serializable;


/**
 * Parent class for Joruanls and Conference papers
 *
 */

public class Serial  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -563646877436713083L;
	//subclass me
}
